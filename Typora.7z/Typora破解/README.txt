1. 放 Typora 根目录, cmd 运行 license-gen.exe, 复制生成的序列号
2. 运行 TyproaCrack.exe
3. 打开 Typora 粘贴生成的序列号